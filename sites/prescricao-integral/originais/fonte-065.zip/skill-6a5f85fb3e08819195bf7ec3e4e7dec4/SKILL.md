---
name: receituario-pediatrico-seguro
description: Elaborar, revisar ou atualizar receituários pediátricos domiciliares e orientações de alta com cálculo por peso, apresentações brasileiras, tripla checagem matemática-farmacêutica-clínica, checagem reversa, medidas não farmacológicas, evolução esperada, sinais de alarme e retorno. Usar sempre que o pedido envolver prescrição, receita, posologia ou orientação medicamentosa pediátrica ambulatorial, inclusive IVAS, febre e medicamentos em mL ou gotas.
---

# Receituário Pediátrico Seguro

## Aplicar a hierarquia de segurança

1. Priorizar segurança clínica, individualização, bula/diretriz atualizada e julgamento clínico sobre formato ou preferência.
2. Não presumir diagnóstico, gravidade, alergias, comorbidades, medicamentos concomitantes ou função renal/hepática.
3. Solicitar somente o dado ausente que possa mudar materialmente a segurança. Se possível, oferecer fórmula parametrizada sem inventar valores.
4. Distinguir tratamento indicado, opcional/“se necessário” e off-label. Não incluir medicamentos apenas para preencher uma categoria.
5. Nunca inventar apresentações, concentrações, gotas/mL, estabilidade, compatibilidade, doses ou fontes.
6. Ler [arquivo-mestre.md](references/arquivo-mestre.md) antes de elaborar ou revisar qualquer receituário.

## Pesquisar e validar

Pesquisar fontes atuais em toda prescrição pediátrica, por se tratar de tema de alto risco. Priorizar, conforme pertinência: protocolos municipais de Belo Horizonte e Região Metropolitana; SES-MG; SBP; Ministério da Saúde; ANVISA e bula oficial; outras sociedades brasileiras; diretrizes internacionais e literatura primária.

Para cada medicamento, confirmar em fontes independentes quando possível:

- indicação, idade mínima e faixa de dose;
- dose máxima por administração e diária;
- apresentação efetivamente disponível e concentração;
- contraindicações, interações e ajustes renal/hepático;
- restrições regulatórias e condição off-label.

Informar divergências relevantes, data e aplicabilidade. Não usar uma fonte secundária isolada para sustentar dose incomum ou de alto risco.

## Executar tripla checagem

1. **Matemática:** calcular na unidade clínica original; mostrar fórmula, dose ponderal, dose total e arredondamento.
2. **Farmacêutica:** confirmar princípio ativo, apresentação, concentração e conversão independente para mL/gotas.
3. **Clínica:** validar indicação, faixa terapêutica, máximos, intervalo, duração, idade, contraindicações, interações e ajustes.
4. **Reversa:** multiplicar volume pela concentração e confirmar a dose; recalcular mg/kg/dose e mg/kg/dia.

Em medicamento de alta vigilância, destacar dupla checagem humana de peso, unidade, concentração, via e programação. Não declarar “tripla checagem concluída” se algum componente não puder ser verificado; explicitar a lacuna.

## Produzir a resposta

Usar a estrutura fixa do arquivo-mestre e omitir vias não indicadas. Numerar medicamentos. Para cada item, fornecer apresentação/concentração, indicação, dose de referência, dose ponderal e total, volume inequívoco, via, intervalo, duração, máximos pertinentes e alertas essenciais.

Escolher uma dose e um volume claros para o cuidador; não transferir a escolha de uma faixa terapêutica ao leigo. Em “se necessário”, indicar sintoma, intervalo mínimo e limite diário.

Entregar texto pronto para copiar e colar, em português brasileiro e linguagem compreensível para responsáveis, sem acrescentar dados clínicos não fornecidos. Quando solicitado ou quando as ferramentas permitirem no fluxo do usuário, gerar também DOCX e PDF equivalentes e visualmente verificados.

## Aplicar regras específicas

- Para IVAS, seguir higiene nasal e avaliar individualmente solução hipertônica, medicamentos para tosse/secreção, antialérgicos, broncodilatador e corticoides. Não prescrever xaropes ou descongestionantes por rotina.
- Usar mel apenas a partir de 12 meses quando apropriado.
- Evitar vasoconstritores tópicos e descongestionantes sistêmicos em crianças, salvo indicação excepcional e avaliação individual.
- Não usar codeína ou clobutinol rotineiramente; verificar restrições atuais antes de mencioná-las como opção.
- Tratar desconforto e contexto clínico, não apenas o número da temperatura. Se usar temperatura axilar ≥37,5 °C como limiar operacional domiciliar, explicar que definições variam.
- Descrever evolução esperada de forma condicionada; incluir sinais de alarme específicos e retorno programado/imediato.

## Revisar antes de entregar

Conferir todos os itens da lista final do arquivo-mestre. Se faltarem dados impeditivos, interromper a prescrição definitiva e declarar exatamente o que falta.
